import React from "react";
import { Helmet } from "react-helmet";
import "../App.css";

function Kontakt() {
  return (
    <div className="App">
      <Helmet>
        <title>Kontakt - U Krvavého barona</title>
      </Helmet>
      <main>
        <h1>Kontakt</h1>
      </main>
    </div>
  );
}

export default Kontakt;

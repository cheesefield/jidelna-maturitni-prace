import React from "react";
import { Helmet } from "react-helmet";
import "../App.css";

function Domu() {
  return (
    <div className="App">
      <Helmet>
        <title>U Krvavého barona</title>
      </Helmet>
      <main>
        <h1>Domů</h1>
      </main>
    </div>
  );
}

export default Domu;

import React from "react";
import { Helmet } from "react-helmet";
import "../App.css";

function ONas() {
  return (
    <div className="App">
      <Helmet>
        <title>O nás - U Krvavého barona</title>
      </Helmet>
      <main>
        <h1>O nás</h1>
        <h2>Jsme jídelna</h2>
      </main>
    </div>
  );
}

export default ONas;

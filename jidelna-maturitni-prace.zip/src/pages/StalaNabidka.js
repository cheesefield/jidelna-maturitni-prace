import React from "react";
import { Helmet } from "react-helmet";
import "../App.css";

function StalaNabidka() {
  return (
    <div className="App">
      <Helmet>
        <title>Stálá nabídka - U Krvavého barona</title>
      </Helmet>
      <main>
        <h1>Stálá nabídka</h1>
      </main>
    </div>
  );
}

export default StalaNabidka;
